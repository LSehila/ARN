

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ARN.ARN;

import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class Test_ARN {
  @Test
  public void testAdd() {
      ARN<Integer> arbre = new ARN<>();
      assertTrue(arbre.add(5)); // Ajout d'un élément
      assertEquals(1, arbre.size()); // Vérifie la taille de l'arbre
  }

  @Test
  public void testContains() {
      ARN<Integer> arbre = new ARN<>();
      arbre.add(5);
      assertTrue(arbre.contains(5)); // Vérifie que l'élément est présent
      assertFalse(arbre.contains(10)); // Vérifie qu'un autre élément n'est pas présent
  }

  @Test
  public void testRemove() {
      ARN<Integer> arbre = new ARN<>();
      arbre.add(5);
      arbre.add(10);
      assertTrue(arbre.remove(5)); // Supprime un élément existant
      assertFalse(arbre.contains(5)); // Vérifie que l'élément a bien été supprimé
  }

  @Test
  public void testRemoveNonExistent() {
      ARN<Integer> arbre = new ARN<>();
      arbre.add(5);
      assertThrows(NullPointerException.class, () -> arbre.remove(10)); // Vérifie qu'une exception est lancée pour un élément inexistant
  }

  @Test
  public void testIterator() {
      ARN<Integer> arbre = new ARN<>();
      arbre.add(5);
      arbre.add(10);
      Iterator<Integer> it = arbre.iterator();
      assertTrue(it.hasNext()); // L'itérateur a des éléments
      assertEquals(5, it.next()); // Vérifie l'ordre des éléments
  }
  
  @Test
  public void testClear() {
      ARN<Integer> arbre = new ARN<>();
      arbre.add(5);
      arbre.add(10);
      arbre.clear();
      assertTrue(arbre.isEmpty()); // Vérifie que l'arbre est vide après clear
  }
  
  @Test
  public void testSizeAfterAddRemove() {
      ARN<Integer> arbre = new ARN<>();
      arbre.add(5);
      arbre.add(10);
      arbre.remove(5);
      assertEquals(1, arbre.size()); // Vérifie la taille après ajout et suppression
  }

  @Test
  public void testAddAll() {
      ARN<Integer> arbre = new ARN<>();
      List<Integer> liste = Arrays.asList(5, 10, 15);
      arbre.addAll(liste);
      assertTrue(arbre.containsAll(liste)); // Vérifie que tous les éléments ont été ajoutés
  }
}
