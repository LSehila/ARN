package ARN;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class Etude_Experimentale {
	public static void main(String[] args) {
        int[] tailles = {10000, 100000 , 200000 , 500000 , 1000000 , 5000000};
        
        for (int n : tailles) {
            System.out.println("Test avec " + n + " éléments");

            // Cas 1 : Ordre aléatoire
            List<Integer> ordreAleatoire = genererOrdreAleatoire(n);
            testerConstructionABR(ordreAleatoire, "Ordre Aléatoire");
            testerConstructionARN(ordreAleatoire, "Ordre Aléatoire");
            testerRechercheABR(ordreAleatoire);
            testerRechercheARN(ordreAleatoire);

            // Cas 2 : Ordre croissant
            List<Integer> ordreCroissant = genererOrdreCroissant(n);
            testerConstructionABR(ordreCroissant, "Ordre Croissant");
            testerConstructionARN(ordreCroissant, "Ordre Croissant");
            
            System.out.println();
        }
    }
	
	private static List<Integer> genererOrdreAleatoire(int n) {
	    Random random = new Random(System.currentTimeMillis());
	    
	    // Mélange aléatoire de la liste
        List<Integer> ordre = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            ordre.add(random.nextInt(2 * n));
        }
        Collections.shuffle(ordre, random);
        return ordre;
    }
	
	private static List<Integer> genererOrdreCroissant(int n) {
        List<Integer> ordre = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            ordre.add(i);
        }
        return ordre;
    }
	
	private static void testerConstructionABR(List<Integer> ordre, String scenario) {
        ABR<Integer> ABR = new ABR<>();

        long tempsDebut = System.currentTimeMillis();
        for (Integer cle : ordre) {
            ABR.add(cle);
        }
        long tempsFin = System.currentTimeMillis();

        System.out.println("Temps de Construction (" + scenario + ") ABR: " + (tempsFin - tempsDebut) + " millisecondes");
    }

	private static void testerRechercheABR(List<Integer> ordre) {
	    // Diviser la liste d'ordre en deux parties
	    int moitie = ordre.size() / 2;
	    List<Integer> premiereMoitie = ordre.subList(0, moitie);
	    List<Integer> deuxiemeMoitie = ordre.subList(moitie, ordre.size());

	    // Création de l'arbre ABR avec la première moitié de la liste
	    ABR<Integer> ABR = new ABR<>(premiereMoitie);

	    // Recherche des clés de la deuxième moitié et de la première moitié
	    long tempsDebut = System.currentTimeMillis();
	    for (int cle : deuxiemeMoitie) {
	        boolean contient = ABR.contains(cle);
	    }
	    for (int cle : premiereMoitie) {
	        boolean contient = ABR.contains(cle);
	    }
	    long tempsFin = System.currentTimeMillis();

	    // Mesure du temps d'exécution
	    System.out.println("Temps de Recherche ABR : " + (tempsFin - tempsDebut) + " millisecondes");
	}
	
	private static void testerConstructionARN(List<Integer> ordre, String scenario) {
        ARN<Integer> arn = new ARN<>();

        long tempsDebut = System.currentTimeMillis();
        for (Integer cle : ordre) {
            arn.add(cle);
        }
        long tempsFin = System.currentTimeMillis();

        System.out.println("Temps de Construction (" + scenario + ") ARN : " + (tempsFin - tempsDebut) + " millisecondes");
    }

	private static void testerRechercheARN(List<Integer> ordre) {
	    // Diviser la liste d'ordre en deux parties
	    int moitie = ordre.size() / 2;
	    List<Integer> premiereMoitie = ordre.subList(0, moitie);
	    List<Integer> deuxiemeMoitie = ordre.subList(moitie, ordre.size());

	    // Création de l'arbre ARN avec la première moitié de la liste
	    ARN<Integer> arn = new ARN<>(premiereMoitie);

	    // Recherche des clés de la deuxième moitié et de la première moitié
	    long tempsDebut = System.currentTimeMillis();
	    for (int cle : deuxiemeMoitie) {
	        boolean contient = arn.contains(cle);
	    }
	    for (int cle : premiereMoitie) {
	        boolean contient = arn.contains(cle);
	    }
	    long tempsFin = System.currentTimeMillis();

	    // Mesure du temps d'exécution
	    System.out.println("Temps de Recherche ARN : " + (tempsFin - tempsDebut) + " millisecondes");
	}
}
